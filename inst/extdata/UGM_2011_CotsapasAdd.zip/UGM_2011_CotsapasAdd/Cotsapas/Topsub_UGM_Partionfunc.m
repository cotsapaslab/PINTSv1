function [PartitionFunction] = Topsub_UGM_Partionfunc(nNull, dataDir, resultDir)

N = str2num(nNull)
logZvalues = zeros(1)
for i=1:N
	adjMatrix = strcat(dataDir, 'adjMatrix', num2str(i),'.txt');
	nodePot = strcat(dataDir, 'nodePot', num2str(i),'.txt');
	edgePot = strcat(dataDir, 'edgePot', num2str(i),'.txt');
	%fprintf(adjMatrix)
	%fprintf(edgePot)
	%fprintf(nodePot)

	nodeStates = strcat(dataDir, 'nodeStates', num2str(i),'.txt');
	logZ = UGM_Partionfunc(adjMatrix, nodePot, edgePot)
	logZvalues(i) = logZ
	%fprintf('Function called from UGM_Topsub_Partionfunc...\n');
	%fprintf('Log of partition function: %f\n',logZ);
end

%Write the Partition function 
resultfile = strcat(resultDir,'Partionfunction.txt')
dlmwrite(resultfile, logZvalues, '\n')
