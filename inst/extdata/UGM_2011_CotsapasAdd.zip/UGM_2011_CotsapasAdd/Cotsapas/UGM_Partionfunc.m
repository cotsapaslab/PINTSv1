function [logZ] = UGM_Partionfunc(adjMatrixFile, nodePotFile, edgePotFile)

%Consider a binary variable of node (on/off state) 
%nNodes=98 for top subnet 
nStates = 2;

%Read datafiles to construct UGM
adj = load(adjMatrixFile)
nodePot = load(nodePotFile)
eP = load(edgePotFile)
%nodeStates = load(nodeStatesFile)

% Make edgeStruct 
fprintf('This is what the edgeStruct looks like:\n');
edgeStruct = UGM_makeEdgeStruct(adj,nStates)

fprintf('Here is the number of states vector:\n');
edgeStruct.nStates

fprintf('Here are the edges:\n');
edgeEnds = edgeStruct.edgeEnds

fprintf('Here are the nodes associated with edge 1:\n');
edge = 1;
edgeStruct.edgeEnds(edge,:)

fprintf('Here are the edge numbers connected to node 1:\n');
n = 1;
edges = UGM_getEdges(n,edgeStruct);

fprintf('Here are the neighbours of node %d\n',n);
nodes = edgeStruct.edgeEnds(edges,:);
nodes(nodes ~= n)

% Make edge 
maxState = max(edgeStruct.nStates);
edgePot = zeros(maxState,maxState,edgeStruct.nEdges);
for e = 1:edgeStruct.nEdges
   edgePot(:,:,e) = vec2mat(eP(e,:),2) ; %[2 1 ; 1 2]; 
end

fprintf('Computing Node Marginals, Edge Marginals, and Log of Normalizing Constant...\n');
[nodeBel,edgeBel,logZ] = UGM_Infer_LBP(nodePot,edgePot,edgeStruct);

fprintf('Partition function: %f\n',exp(logZ));
fprintf('Log of partition function: %f\n',logZ);
