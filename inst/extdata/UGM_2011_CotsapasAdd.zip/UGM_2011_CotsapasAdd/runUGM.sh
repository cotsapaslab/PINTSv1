#/bin/bash

#Directories
matlabPath=$5 #/usr/local/cluster/software/matlab-2013b/bin/
PATH=$matlabPath:$PATH
UGMDir=$4 #HOME/Complex_disease_network/Algorithm/UGM/  
#echo $matlabPath
#echo $UGMDir

#Paramters
nNull=$1
UGMInput=$2
UGMOutput=$3
#echo $nNull
#echo $UGMInput
#echo $UGMOutput

parameters="'$nNull', '$UGMInput', '$UGMOutput'"
#echo $parameters

cd $UGMDir
#echo $PATH

#which matlab
matlab -nodesktop -nosplash -r  "mexAll;addpath(genpath(pwd));Topsub_UGM_Partionfunc(""$parameters"");quit"

